class CreateMassMailer < ActiveRecord::Migration[6.0]
  def change
    create_table :mass_mailers do |t|
      # TODO: fields
    end
  end
end
