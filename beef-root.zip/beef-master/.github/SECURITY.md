send security bug reports to security@beefproject.com

**A security report should include:**

1. Description of the problem (what it is, what's the impact)

2. Technical steps to replicate it (commands / screenshots)

3. Actionable fix/recommendations to mitigate the issue
